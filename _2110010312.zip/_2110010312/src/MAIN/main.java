/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package MAIN;
import  CLASS.*;
import DATASET.*;
import java.util.Scanner;
import FORMS.*;
/**
 *
 * @author ASUS
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        Scanner scanner = new Scanner(System.in);
//        String User;
//        boolean lanjutkan = true;
//        int input = 0;
//        while(lanjutkan)
//        
//        {
//        System.out.println("----------SELAMAT DATANG-----------");
//        System.out.println("TOKO SEHAT JAYA ELEKTRONIK PACITAN ");
//        System.out.println("-----------------------------------");
//        System.out.println("1. KERANJANG");
//        System.out.println("2. PEMBUKUAN");
//        System.out.println("3. PENGATURAN");
//        System.out.println();
//        System.out.print("Pilihan anda: ");
//        User = scanner.next();
//        
//        switch (User){
//            case"1":
//                
//                // KERANJANG, BARANG, PRODUK, KATEGORI
//                
//                // DATASET KERANJANG
//                
//                datasetKeranjang idKeranjang = new datasetKeranjang();
//                    idKeranjang.insertidKeranjang(1);
//                
//                datasetKeranjang banyaknya = new datasetKeranjang();
//                    banyaknya.insertbanyaknya(1);
//                
//                datasetKeranjang barangId = new datasetKeranjang();
//                    barangId.insertbarangId(1);
//                    
//                datasetKeranjang induk = new datasetKeranjang();
//                induk.insertindukKeranjang(1);
//                
//                datasetKeranjang logKeranjang = new datasetKeranjang();
//                    logKeranjang.insertlogKeranjang("1");
//                   
//                System.out.println("=============================");
//                System.out.println("KERANJANG");
//                System.out.println("=============================");
//                System.out.println("Keranjang: "+induk.getRecordindukKeranjang());
//                System.out.println("Id: "+idKeranjang.getRecordidKeranjang());
//                System.out.println("Jumlah"+banyaknya.getRecordbanyaknya());
//                System.out.println("IdBarang"+barangId.getRecordbarangId());
//                System.out.println("Total"+logKeranjang.getRecordlogKeranjang());
//                System.out.println();
//                System.out.println("MASUKKAN PILIHAN ANDA 1-2 UNTUK MELIHAT DETAIL PRODUK ATAUPUN DETAIL TRANSAKSI");
//                System.out.println("=============================");
//                System.out.println("1. DETAIL PRODUK");
//                System.out.println("2. DETAIL TRANSAKSI");
//                System.out.println("3. DETAIL BARANG");
//                System.out.println("=============================");
//                System.out.println("Pilihan Anda: ");
//                input = scanner.nextInt();
//                
//                if(input == 1){
//                    
//                    // DATASET PRODUK 
//                    
//                    // ID PRODUK
//                    
//                        datasetProduk idProduk = new datasetProduk();
//                        idProduk.insertidProduk(1);
//                        System.out.println("Id: "+idProduk.getRecordidProduk());
//
//                    // NAMA PRODUK
//                    
//                        datasetProduk namaProduk = new datasetProduk();
//                        namaProduk.insertnamaProduk("Vivobook Pro 14 OLED(M3400, AMD Ryzen 5000 Series Mobile Processor)");
//                        System.out.println("Nama Produk: "+namaProduk.getRecordnamaProduk());
//
//                    // KATEGORI
//                    
//                        datasetProduk kategori = new datasetProduk();
//                        kategori.insertkategori("Laptop");
//                        System.out.println("Kategori: "+kategori.getRecordkategori());
//                
//                }else if(input == 2){
//                    
//                    // DATASET TRANSAKSI
//                    
//                    // ID TRANSAKSI
//                    
//                        datasetTransaksi idTransaksi = new datasetTransaksi();
//                        idTransaksi.insertidTransaksi(1);
//                        System.out.println("Id: "+idTransaksi.getRecordidTransaksi());
//
//                    // PEMBAYARAN
//                    
//                        datasetTransaksi pembayaran = new datasetTransaksi();
//                        pembayaran.insertpembayaran("9.499.000");
//                        System.out.println("Total Pembayatan"+pembayaran.getRecordpembayaran());
//
//                    // KERANJANG INDUK
//                    
//                        datasetTransaksi keranjangInduk = new datasetTransaksi();
//                        keranjangInduk.insertkeranjangInduk(1);
//                        System.out.println("Keranjang: "+keranjangInduk.getRecordkeranjangInduk());
//
//                    // LOG TRANSAKSI
//                    
//                        datasetTransaksi logTransaksi = new datasetTransaksi();
//                        logTransaksi.insertlogTransaksi("Transaksi Sukses");
//                        System.out.println(logTransaksi.getRecordlogTransaksi());    
//                
//                }else if(input == 3){
//                    // DATASET BARANG
//
//                    // ID BARANG
//
//                          datasetBarang idBarang = new datasetBarang();
//                          idBarang.insertidBarang(1);
//                          idBarang.insertidBarang(2);
//                          System.out.println("Id: "+idBarang.getRecordidBarang());
//
//                    // NAMA BARANG
//
//                          datasetBarang namaBarang = new datasetBarang();
//                          namaBarang.insertnamaBarang("Vivobook Pro 14 OLED(M3400, AMD Ryzen 5000 Series Mobile Processor)");
//                          System.out.println("Nama Barang: "+namaBarang.getRecordnamaBarang());
//
//                    // HARGA MODAL
//                          datasetBarang modal = new datasetBarang();
//                          modal.inserthargaModal("9.000.000");
//                          modal.inserthargaModal("0");
//                          System.out.println("Harga Modal: "+modal.getRecordhargaModal());
//
//                    // HARGA JUAL
//
//                          datasetBarang jual = new datasetBarang();
//                          jual.inserthargaJual("9.499.000");
//                          jual.inserthargaJual("0");
//                          System.out.println("Harga Jual: "+jual.getRecordhargaJual());
//
//                    // PERSEDIAAN
//
//                          datasetBarang persediaan = new datasetBarang();
//                          persediaan.insertpersediaan(8);
//                          persediaan.insertpersediaan(0);
//                          System.out.println("Jumlah Persediaan: "+persediaan.getRecordpersediaan());
//
//                    // PRODUK ID
//
//                          datasetBarang produk = new datasetBarang();
//                          produk.insertprodukId(1);
//                          System.out.println("Id Produk: "+produk.getRecordprodukId());
//
//                   // LOG BARANG
//
//                          datasetBarang log = new datasetBarang();
//                          log.insertlogBarang("Stok Masih Ada");
//                          log.insertlogBarang("Stok Sudah Habis");
//                          System.out.println(log.getRecordlogBarang());
//
//                              }
//       
//                break;
//                
//            
//             case "2":
//                System.out.println("=============================");
//                System.out.println("PEMBUKUAN");
//                System.out.println("=============================");
//                
//                    // DATASET PEMBUKUAN
//
//                    // ID PEMBUKUAN
//                            datasetPembukuan idPembukuan = new datasetPembukuan();
//                            idPembukuan.insertidPembukuan(1);
//                            System.out.println("Id: "+idPembukuan.getRecordidPembukuan());
//
//                    // DEBET
//                            datasetPembukuan debet = new datasetPembukuan();
//                            debet.insertdebet("100.000.000");
//                            System.out.println("Debet: "+debet.getRecorddebet());
//
//                   // KREDIT
//                            datasetPembukuan kredit = new datasetPembukuan();
//                            kredit.insertkredit("35.000.000");
//                            System.out.println("Kredit: "+kredit.getRecordkredit());
//
//                   // KETERANGAN
//                            datasetPembukuan keterangan = new datasetPembukuan();
//                            keterangan.insertketerangan("");
//                            System.out.println("Keterangan: "+keterangan.getRecordketerangan());
//
//                    // LOG PEMBUKUAN
//                            datasetPembukuan logPembukuan = new datasetPembukuan();
//                            logPembukuan.insertlogPembukuan("");
//                            System.out.println(logPembukuan.getRecordlogPembukuan());
//
//            break;
//            
//             case "3":
//                System.out.println("=============================");
//                System.out.println("PENGATURAN");
//                System.out.println("=============================");
//                
//                    // DATASET PENGATURAN
//                
//                    // ID PENGATURAN
//                            datasetPengaturan idPengaturan = new datasetPengaturan();
//                            idPengaturan.insertidPengaturan(1);
//                            System.out.println("Id: "+idPengaturan.getRecordidPengaturan());
//
//                     // NAMA TOKO
//                            datasetPengaturan namaToko = new datasetPengaturan();
//                            namaToko.insertnamaToko("TOKO SEHAT JAYA ELEKTRONIK PACITAN");
//                            System.out.println("Nama Toko: "+namaToko.getRecordnamaToko());
//
//
//                     // NOMOR TELEPON
//
//                            datasetPengaturan nomor = new datasetPengaturan();
//                            nomor.insertnomorTelepon("081347200089");
//                            System.out.println("Nomor: "+nomor.getRecordnomorTelepon());
//
//                      // ALAMAT
//
//                            datasetPengaturan alamat = new datasetPengaturan();
//                            alamat.insertalamat("Kec.Pacitan, Kabupaten Pacitan, Jawa Timur");
//                            System.out.println("Alamat : "+alamat.getRecordalamat());
//     
//            break;
//            
//             default:
//                System.err.println("\nInput anda tidak ditemukan\nSilahkan pilih 1-3");
//            break;
//        }
//        System.out.print("\nApakah anda Ingin melanjutkan (y/n)? ");
//        User = scanner.next();
//        lanjutkan = User.equalsIgnoreCase("y");
//        }
        
                new frameUtama().setVisible(true);
    }
    
}
