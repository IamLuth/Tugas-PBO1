/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DATASET;
import java.util.ArrayList;


/**
 *
 * @author ASUS
 */
public class datasetBarang {
    
    private ArrayList<Integer>  idBarang;
    private ArrayList<String>   namaBarang;
    private ArrayList<String>   hargaModal;
    private ArrayList<String>   hargaJual;
    private ArrayList<Integer>  persediaan;
    private ArrayList<Integer>  produkId;
    private ArrayList<String>   logBarang;
    
    
    public datasetBarang(){
        
        idBarang        = new ArrayList<Integer>();
        namaBarang      = new ArrayList<String>();
        hargaModal      = new ArrayList<String>();
        hargaJual       = new ArrayList<String>();
        persediaan      = new ArrayList<Integer>();
        produkId        = new ArrayList<Integer>();
        logBarang       = new ArrayList<String>();
        
    }
    
    public void insertidBarang(Integer isi){
    
        this.idBarang.add(isi);
    }
    
    public ArrayList<Integer> getRecordidBarang() {
            
            return this.idBarang;
        }
    
    public void insertnamaBarang(String isi){
    
        this.namaBarang.add(isi);
    
    }
    
    public ArrayList<String> getRecordnamaBarang(){
        
        return this.namaBarang;
    
    }
    
    public void inserthargaModal(String isi){
        
        this.hargaModal.add(isi);
        
    }
    
    public ArrayList<String> getRecordhargaModal(){
        
        return this.hargaModal;
        
    }
    
    public void inserthargaJual(String isi){
        
        this.hargaJual.add(isi);
        
    }
    
    public ArrayList<String> getRecordhargaJual(){
        
        return this.hargaJual;
    
    }
    
    public void insertpersediaan(Integer isi){
        
        this.persediaan.add(isi);
        
    }
    
    public ArrayList<Integer> getRecordpersediaan(){
       
        return this.persediaan;
    
    }
    
     public void insertprodukId(Integer isi){
        
        this.produkId.add(isi);
        
    }
    
    public ArrayList<Integer> getRecordprodukId(){
       
        return this.produkId;
    
    }
    
     public void insertlogBarang(String isi){
        
        this.logBarang.add(isi);
        
    }
    
    public ArrayList<String> getRecordlogBarang(){
       
        return this.logBarang;
    
    }
    
   

    

 
}

   
        
    
    

