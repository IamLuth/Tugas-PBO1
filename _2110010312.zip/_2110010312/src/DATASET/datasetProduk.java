/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DATASET;
import java.util.ArrayList;
/**
 *
 * @author ASUS
 */
public class datasetProduk {

    private ArrayList<Integer> idProduk;
    private ArrayList<String> namaProduk;
    private ArrayList<String> kategori;
    
    public datasetProduk (){
        
        idProduk = new ArrayList<Integer>();
        namaProduk = new ArrayList<String>();
        kategori = new ArrayList<String>();
        
    }
    
    public void insertidProduk(Integer isi){
        
        this.idProduk.add(isi);
    }
    
    public ArrayList<Integer>getRecordidProduk(){
        
        return this.idProduk;
        
    }
    
     public void insertnamaProduk(String isi){
        
        this.namaProduk.add(isi);
    }
    
    public ArrayList<String>getRecordnamaProduk(){
        
        return this.namaProduk;
        
    }
    
     public void insertkategori(String isi){
        
        this.kategori.add(isi);
    }
    
    public ArrayList<String>getRecordkategori(){
        
        return this.kategori;
        
    }
    
}
