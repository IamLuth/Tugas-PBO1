/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DATASET;
import java.util.ArrayList;
/**
 *
 * @author ASUS
 */
public class datasetTransaksi {
    
    private ArrayList<Integer> idTransaksi;
    private ArrayList<String> pembayaran;
    private ArrayList<Integer> keranjangInduk;
    private ArrayList<String> logTransaksi;
    
    public datasetTransaksi(){
        
        idTransaksi = new ArrayList<Integer>();
        pembayaran  = new ArrayList<String>();
        keranjangInduk = new ArrayList<Integer>();
        logTransaksi = new ArrayList<String>();
    }
    
    public void insertidTransaksi(Integer isi){
        
        this.idTransaksi.add(isi);
        
    }
    
    public ArrayList<Integer> getRecordidTransaksi(){
        
        return this.idTransaksi;
        
    }
    
     public void insertpembayaran(String isi){
        
        this.pembayaran.add(isi);
        
    }
    
    public ArrayList<String> getRecordpembayaran(){
        
        return this.pembayaran;
        
    }
    
     public void insertkeranjangInduk(Integer isi){
        
        this.keranjangInduk.add(isi);
        
    }
    
    public ArrayList<Integer> getRecordkeranjangInduk(){
        
        return this.keranjangInduk;
        
    }
    
     public void insertlogTransaksi(String isi){
        
        this.logTransaksi.add(isi);
        
    }
    
    public ArrayList<String> getRecordlogTransaksi(){
        
        return this.logTransaksi;
        
    }
}
