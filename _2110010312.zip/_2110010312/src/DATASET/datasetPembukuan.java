/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DATASET;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class datasetPembukuan {
    
    private ArrayList<Integer>  idPembukuan;
    private ArrayList<String>   debet;
    private ArrayList<String>   kredit;
    private ArrayList<String>   keterangan;
    private ArrayList<String>   logPembukuan;
    
public datasetPembukuan(){
    
    idPembukuan     = new ArrayList<Integer>();
    debet           = new ArrayList<String>();
    kredit          = new ArrayList<String>();
    keterangan      = new ArrayList<String>();
    logPembukuan    = new ArrayList<String>();
  
}

public void insertidPembukuan(Integer isi){
    
    this.idPembukuan.add(isi);
    
}

public ArrayList<Integer>getRecordidPembukuan(){
    
    return this.idPembukuan;

}

public void insertdebet(String isi){
    
    this.debet.add(isi);
    
}

public ArrayList<String> getRecorddebet(){
    
    return this.debet;
    
}

public void insertkredit (String isi){
    
    this.kredit.add(isi);
    
}

public ArrayList<String> getRecordkredit(){
    
    return this.kredit;
    
}

public void insertketerangan (String isi){
    
    this.keterangan.add(isi);
    
}

public ArrayList<String> getRecordketerangan(){
    
    return this.keterangan;
    
}

public void insertlogPembukuan (String isi){
    
    this.logPembukuan.add(isi);
    
}

public ArrayList<String> getRecordlogPembukuan(){
    
    return this.logPembukuan;
}
}
