/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DATASET;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class datasetKategori {
    
    private ArrayList<Integer>idKategori;
    private ArrayList<String>namaKategori;
    
    public datasetKategori(){

    idKategori      = new ArrayList<Integer>();
    namaKategori    = new ArrayList<String>();

    }
    
    public void insertidKategori(Integer isi){
       
        this.idKategori.add(isi);
    
    }
    
    public ArrayList<Integer> getRecordidKategori(){
        
        return this.idKategori;
    
    }
    
      public void insertnamaKategori(String isi){
       
        this.namaKategori.add(isi);
    
    }
    
    public ArrayList<String> getRecordnamaKategori(){
        
        return this.namaKategori;
    
    }
    
   

    
}

