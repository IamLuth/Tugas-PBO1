/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DATASET;
import java.util.ArrayList;
/**
 *
 * @author ASUS
 */
public class datasetKeranjang {
    
    private ArrayList<Integer> idKeranjang;
    private ArrayList<Integer> banyaknya;
    private ArrayList<Integer> barangId;
    private ArrayList<Integer> indukKeranjang;
    private ArrayList<String> logKeranjang;
    
    public datasetKeranjang(){
        
        idKeranjang     = new ArrayList<Integer>();
        banyaknya       = new ArrayList<Integer>();
        barangId        = new ArrayList<Integer>();
        indukKeranjang  = new ArrayList<Integer>();
        logKeranjang    = new ArrayList<String>();
    }
    
    public void insertidKeranjang(Integer isi){
       
        this.idKeranjang.add(isi);
    
    }
    
    public ArrayList<Integer> getRecordidKeranjang(){
        
        return this.idKeranjang;
    
    }
    
    public void insertbanyaknya(Integer isi){
        
        this.banyaknya.add(isi);
    
    }
    
    public ArrayList<Integer> getRecordbanyaknya(){
        
        return this.banyaknya;
    
    }
    
    public void insertbarangId(Integer isi){
        
        this.barangId.add(isi);
    
    }
    
    public ArrayList<Integer> getRecordbarangId(){
        
        return this.barangId;
        
    }
    
    public void insertindukKeranjang(Integer isi){
        
        this.indukKeranjang.add(isi);
    
    }
    
    public ArrayList<Integer> getRecordindukKeranjang(){
        
        return this.indukKeranjang;
    
    }
    
    public void insertlogKeranjang(String isi){
        
        this.logKeranjang.add(isi);
    
    }
    
    public ArrayList<String> getRecordlogKeranjang(){
        
        return this.logKeranjang;
    }
    
    
    
}
