/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DATASET;
import java.util.ArrayList;
/**
 *
 * @author ASUS
 */
public class datasetPengaturan {
    
    private ArrayList<Integer> idPengaturan;
    private ArrayList<String> namaToko;
    private ArrayList<String> nomorTelepon;
    private ArrayList<String> alamat;
    
    public datasetPengaturan(){
        
        idPengaturan    = new ArrayList<Integer>();
        namaToko        = new ArrayList<String>();
        nomorTelepon    = new ArrayList<String>();
        alamat          = new ArrayList<String>();
      
    }
    
    public void insertidPengaturan(Integer isi){
        
        this.idPengaturan.add(isi);
        
    }
    
    public ArrayList<Integer>getRecordidPengaturan(){
        
        return this.idPengaturan;
        
    }
    
        public void insertnamaToko(String isi){
        
        this.namaToko.add(isi);
        
    }
    
    public ArrayList<String>getRecordnamaToko(){
        
        return this.namaToko;
        
    }
    
        public void insertnomorTelepon(String isi){
        
        this.nomorTelepon.add(isi);
        
    }
    
    public ArrayList<String>getRecordnomorTelepon(){
        
        return this.nomorTelepon;
        
    }
    
          public void insertalamat(String isi){
        
        this.alamat.add(isi);
        
    }
    
    public ArrayList<String>getRecordalamat(){
        
        return this.alamat;
        
    }
    
}
