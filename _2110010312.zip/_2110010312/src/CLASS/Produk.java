/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CLASS;

/**
 *
 * @author ASUS
 */
    // CLASS PRODUK

        public class Produk {
            private int idProduk;
            private String namaProduk;
            private String kategori;
    
    // CONSTRUCTOR
            
        public Produk(int idProduk, String namaProduk, String kategoriId) {
            this.idProduk = idProduk;
            this.namaProduk = namaProduk;
            this.kategori = kategori;
            
    }

     // OVERLOAD CONSTRUCTOR
        
        public Produk(int idProduk, String namaProduk){
            this.idProduk = idProduk;
            this.namaProduk = namaProduk;
        
    }
    
    // METHOD
        
        public void printProduk() {
            System.out.println("Produk: " + namaProduk);
            
    }

    //OVERLOAD METHOD
        
        public void printProduk(String kategori) {
            System.out.println("Produk: " + namaProduk + ", Kategori: " + kategori);
            
    }
}
