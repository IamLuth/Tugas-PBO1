/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CLASS;

/**
 *
 * @author ASUS
 */
    // CLASS PENGATURAN

        public class Pengaturan {
            private int idPengaturan;
            private String namaToko;
            private String nomorTelepon;
            private String alamat;
    
    // CONSTRUCTOR
            
        public Pengaturan(int idPengaturan, String namaToko, String nomorTelepon, String alamat) {
            this.idPengaturan = idPengaturan;
            this.namaToko = namaToko;
            this.nomorTelepon = nomorTelepon;
            this.alamat = alamat;
    }

    // METHOD
        
        public void printInfoToko() {
            System.out.println("Nama Toko: " + namaToko);
            System.out.println("Alamat: " + alamat);
            System.out.println("Nomor Telepon: " + nomorTelepon);
}
}
