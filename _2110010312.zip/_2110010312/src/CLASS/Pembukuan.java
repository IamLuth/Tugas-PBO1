/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CLASS;

/**
 *
 * @author ASUS
 */
    // CLASS PEMBUKUAN

        public class Pembukuan {
            private int idPembukuan;
            private String debet;
            private String kredit;
            private String keterangan;
            private String logPembukuan;
    
    // CONSTRUCTOR
        
        public Pembukuan(int idPembukuan, String debet, String kredit, String keterangan, String logPembukuan) {
            this.idPembukuan = idPembukuan;
            this.debet = debet;
            this.kredit = kredit;
            this.keterangan = keterangan;
            this.logPembukuan = logPembukuan;
        
    }

    // OVERLOAD CONSTRUCTOR
        
        public Pembukuan(int idPembukuan, String debet, String kredit, String keterangan) {
            this(idPembukuan, debet, kredit, keterangan, "");
            
    }

    // METHOD
        
        public void tambahDebet(String tambah) {
            this.debet += tambah;
            
    }

    // OVERLOAD METHOD
        
        public void tambahDebet() {
            tambahDebet("");
}
}
