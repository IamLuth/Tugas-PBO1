/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ASUS
 */
public class Keranjang {
    private int id_keranjang;
    private int banyaknya;
    private int barang_id;
    private int induk_keranjang;
    private String log_keranjang;
    
    // CONSTRUCTOR
    public Keranjang(int id_keranjang, int banyaknya, int barang_id, int induk_keranjang, String log_keranjang) {
        this.id_keranjang = id_keranjang;
        this.banyaknya = banyaknya;
        this.barang_id = barang_id;
        this.induk_keranjang = induk_keranjang;
        this.log_keranjang = log_keranjang;
    }
    // OVERLOAD CONSTRUCTOR
    public Keranjang(int id_keranjang, int banyaknya, int barang_id) {
        this(id_keranjang, banyaknya, barang_id, 0, "");
    }
    
    // METHOD
    public void method1() {
        
    }
    
    // OVERLOAD METHOD
    public void method1(int arg1) {
        
    }
    public int getIdKeranjang() {
        return id_keranjang;
    }
}
