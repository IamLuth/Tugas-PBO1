/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CLASS;

/**
 *
 * @author ASUS
 */
    // CLASS PEMBUKUAN
    public class Pembukuan {
        private int idPembukuan;
        private double debet;
        private double kredit;
        private String keterangan;
        private String logPembukuan;
    
    // CONSTRUCTOR
    public Pembukuan(int idPembukuan, double debet, double kredit, String keterangan, String logPembukuan) {
        this.idPembukuan = idPembukuan;
        this.debet = debet;
        this.kredit = kredit;
        this.keterangan = keterangan;
        this.logPembukuan = logPembukuan;
    }

    // OVERLOAD CONSTRUCTOR
    public Pembukuan(int idPembukuan, double debet, double kredit, String keterangan) {
        this(idPembukuan, debet, kredit, keterangan, "");
    }

    // METHOD
    public void tambahDebet(double tambah) {
        this.debet += tambah;
    }

    // OVERLOAD METHOD
    public void tambahDebet() {
        tambahDebet(1.0);
}
}
