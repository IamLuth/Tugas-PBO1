/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CLASS;

/**
 *
 * @author ASUS
 */
    // CLASS TRANSAKSI
    public class Transaksi {
        private int idTransaksi;
        private double pembayaran;
        private int keranjangInduk;
        private String logTransaksi;

    // CONSTRUCTOR
    public Transaksi(int idTransaksi, double pembayaran, int keranjangInduk, String logTransaksi) {
        this.idTransaksi = idTransaksi;
        this.pembayaran = pembayaran;
        this.keranjangInduk = keranjangInduk;
        this.logTransaksi = logTransaksi;
    }
    
    // OVERLOAD CONSTRUCTOR
    public Transaksi(int idTransaksi, double pembayaran, int keranjangInduk) {
        this(idTransaksi, pembayaran, keranjangInduk, "");
    }
    
    // METHOD
    public void prosesTransaksi() {
        System.out.println("Transaksi dengan ID: " + idTransaksi + " diproses.");
        System.out.println("Total pembayaran: " + pembayaran);
        System.out.println("Keranjang induk: " + keranjangInduk);
        System.out.println("Log transaksi: " + logTransaksi);
    }

    // OVERLOAD METHOD
    public void prosesTransaksi(double tambahPembayaran) {
        pembayaran += tambahPembayaran;
        prosesTransaksi();
    }

    public void setLogTransaksi(String logTransaksi) {
        this.logTransaksi = logTransaksi;
    }

    public String getLogTransaksi() {
        return logTransaksi;
    }
}