/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CLASS;

/**
 *
 * @author ASUS
 */
    // CLASS BARANG
    public class Barang {
        private int idBarang;
        private String namaBarang;
        private double hargaModal;
        private double hargaJual;
        private int persediaan;
        private int produkId;
        private String logBarang;

    // CONSTRUCTOR
    public Barang(int idBarang, String namaBarang, double hargaModal, double hargaJual, int persediaan, int produkId, String logBarang) {
        this.idBarang = idBarang;
        this.namaBarang = namaBarang;
        this.hargaModal = hargaModal;
        this.hargaJual = hargaJual;
        this.persediaan = persediaan;
        this.produkId = produkId;
        this.logBarang = logBarang;
    }

    // OVERLOAD CONSTRUCTOR
    public Barang(int idBarang, String namaBarang, double hargaModal, double hargaJual, int persediaan) {
        this(idBarang, namaBarang, hargaModal, hargaJual, persediaan, 0, "");
    }

    // METHOD
    public void tambahPersediaan(int tambah){
        this.persediaan += tambah;
    }

    // OVERLOAD METHOD
    public void tambahPersediaan() {
        tambahPersediaan(1);
    }



}

