/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CLASS;

/**
 *
 * @author ASUS
 */
    // CLASS KATEGORI
    public class Kategori {
        private int idKategori;
        private String namaKategori;
    
    // CONSTRUCTOR
    public Kategori(int idKategori, String namaKategori) {
        this.idKategori = idKategori;
        this.namaKategori = namaKategori;
    }

     // OVERLOAD CONSTRUCTOR
    public Kategori() {
        this.idKategori = 0;
        this.namaKategori = "";
}
    
    // METHOD
    public void printKategori() {
        System.out.println("Kategori: " + namaKategori);
    }

    // OVERLOAD METHOD
    public void printKategori(int id) {
        System.out.println("ID Kategori: " + id);
        System.out.println("Kategori: " + namaKategori);
}

}
