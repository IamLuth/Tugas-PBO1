/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CLASS;

/**
 *
 * @author ASUS
 */

    // CLASS KERANJANG
    public class Keranjang {
        private int idKeranjang;
        private int banyaknya;
        private int barangId;
        private int indukKeranjang;
        private String logKeranjang;
    
    // CONSTRUCTOR
    public Keranjang(int idKeranjang, int banyaknya, int barangId, int indukKeranjang, String logKeranjang){
        this.idKeranjang = idKeranjang;
        this.banyaknya = banyaknya;
        this.barangId = barangId;
        this.indukKeranjang = indukKeranjang;
        this.logKeranjang = logKeranjang;
    }
    
    // OVERLOAD CONSTRUCTOR
    public Keranjang(int idKeranjang, int banyaknya, int barangId) {
        this(idKeranjang, banyaknya, barangId, 0, "");
    }
    
    // METHOD
    public void tambahBanyaknya(int tambah) {
        this.banyaknya += tambah;
    }
    
    // OVERLOAD METHOD
    public void tambahBanyaknya() {
        tambahBanyaknya(1);
    }
    
}
