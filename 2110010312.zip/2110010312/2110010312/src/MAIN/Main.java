/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package MAIN;
import CLASS.*;
/**
 *
 * @author ASUS
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // PENGATURAN
    Pengaturan pengaturan = new Pengaturan(1, "Toko Elektronik ", "081347200089", "Jl. EntahBerantah");
    pengaturan.printInfoToko();
        
        // BARANG
    Barang barang1 = new Barang(1, "ASUS VivoBook", 11.500000, 12.000000, 5);
    Barang barang2 = new Barang(2, "Samsung", 4.500000, 5.000000, 8);

    barang1.tambahPersediaan();
    barang2.tambahPersediaan(3);

        // KATEGORI
    Kategori kategori1 = new Kategori(1, "Laptop, PC");
    Kategori kategori2 = new Kategori(2, "Smartphone, Ipad");
    
    kategori1.printKategori();
    kategori2.printKategori();

        // KERANJANG
    Keranjang keranjang1 = new Keranjang(1, 10, 1);
    Keranjang keranjang2 = new Keranjang(2, 10, 2);

    keranjang1.tambahBanyaknya();
    keranjang2.tambahBanyaknya(2);

        // PEMBUKUAN
    Pembukuan pembukuan1 = new Pembukuan(1, 100.599000, 0.0, "Debet");
    Pembukuan pembukuan2 = new Pembukuan(2, 50.399000, 0.0, "Debet");

    pembukuan1.tambahDebet();
    pembukuan2.tambahDebet(75.499439);

        // PRODUK
    Produk produk1 = new Produk(1, "LAPTOP", 1);
    Produk produk2 = new Produk(2, "Smartphone", 2);

    produk1.printProduk();
    produk2.printProduk();

        // TRANSAKSI
    Transaksi transaksi1 = new Transaksi(1, 11.599999, 1);
    transaksi1.setLogTransaksi("Transaksi sukses");
    String logTransaksi1 = transaksi1.getLogTransaksi();
    System.out.println("Log transaksi : " + logTransaksi1);
    
    Transaksi transaksi2 = new Transaksi(2, 5.399999, 2);
    transaksi2.setLogTransaksi("Transaksi sukses");
    String logTransaksi2 = transaksi1.getLogTransaksi();
    System.out.println("Log transaksi : " + logTransaksi2);
    
    transaksi1.prosesTransaksi();
    transaksi2.prosesTransaksi();
    
    }
    }
    

